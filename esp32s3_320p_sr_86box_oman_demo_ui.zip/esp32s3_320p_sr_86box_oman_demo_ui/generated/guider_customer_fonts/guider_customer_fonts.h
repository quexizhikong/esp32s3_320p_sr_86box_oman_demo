
    #ifndef GUIDER_CUSTOMER_FONTS_H
    #define GUIDER_CUSTOMER_FONTS_H
    #ifdef __cplusplus
    extern "C" {
    #endif
    
    #include "lv_font.h"
    
    LV_FONT_DECLARE(lv_customer_font_PingFang_Regular_16)

    
    #ifdef __cplusplus
    }
    #endif
    #endif
    